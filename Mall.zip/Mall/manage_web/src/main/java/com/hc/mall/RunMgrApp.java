package com.hc.mall;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import tk.mybatis.spring.annotation.MapperScan;

@SpringBootApplication
@MapperScan(basePackages = "com.hc.mall.mapper")
public class RunMgrApp {
    public static void main(String[] args){
        SpringApplication.run ( RunMgrApp.class,args );
    }
}
