package com.hc.mall.manager.controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.awt.*;

@RestController
@RequestMapping("/upload")
public class FileUploadController {
    @RequestMapping("/oss")
    public String uploadByOss(MultipartFile file){
        return"";

    }
}
