package com.hc.mall;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RunAPp {
    public static void main(String[] args){
        System.out.println ( "====" );
    }
}
