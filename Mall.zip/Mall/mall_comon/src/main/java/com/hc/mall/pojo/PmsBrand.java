package com.hc.mall.pojo;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name="pms_brand")
public class PmsBrand {
    @Id
    @Column(name="brand_id")
    int id;

    @Column(name="name")
    String name;

    @Column(name="logo")
    String logo;

    @Column(name="descript")
    String descript;

    @Column(name="show_status")
    Integer showStatus;

    @Column(name="first_letter")
    String firstLetter;

    @Column(name="sort")
    Integer sort;
}
