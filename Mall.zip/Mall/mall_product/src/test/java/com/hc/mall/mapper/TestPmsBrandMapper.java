package com.hc.mall.mapper;

import com.hc.mall.ProdRunApp;
import com.hc.mall.pojo.PmsBrand;
import junit.framework.JUnit4TestAdapterCache;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=ProdRunApp.class)
public class TestPmsBrandMapper {
    @Autowired
    PmsBrandMapper pmsBrandMapper;

    @Test
    public void testGetById(){
        PmsBrand pmsBrand=pmsBrandMapper.selectByPrimaryKey ( 1 );
        System.out.println ( pmsBrand );
    }
}
