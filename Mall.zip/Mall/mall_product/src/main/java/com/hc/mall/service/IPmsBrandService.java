package com.hc.mall.service;

import com.hc.mall.dto.PageResult;
import com.hc.mall.pojo.PmsBrand;

import java.util.List;

public interface IPmsBrandService {
    int deleteById(int id);
    int insert(PmsBrand pmsBrand);
    int update(PmsBrand pmsBrand);
    PmsBrand seleteById(int id);
    List<PmsBrand> selectAll();
    PageResult<PmsBrand> selectAllByPage(int pageNo, int pageSize);
    PageResult<PmsBrand> selectAllByPage(int pageNo, int pageSize,String keyword);


}
