package com.hc.mall.controller;

import com.hc.mall.dto.PageResult;
import com.hc.mall.pojo.PmsBrand;
import com.hc.mall.service.IPmsBrandService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;

@Api(description = "品牌管理API")
@RestController
@RequestMapping("/brand")
public class PmsBrandController {

    @Autowired
    IPmsBrandService pmsBrandService;


    @ApiOperation ( "新增品牌" )
    @RequestMapping("insert")
    public int insert(@RequestBody PmsBrand pmsBrand){
        System.out.println ( "==插入数据==" );
        System.out.println (pmsBrand);
        return pmsBrandService.insert ( pmsBrand );
    }


    @ApiOperation ( "删除品牌" )
    @RequestMapping("delete")
    public int delete(int id){
        System.out.println ( "删除" );
        System.out.println ( "id:"+id );
        return pmsBrandService.deleteById ( id );
    }

    @ApiOperation ( "更新品牌" )
    @RequestMapping("update")
    public int update(@RequestBody PmsBrand pmsBrand){
        System.out.println ( "==更新品牌数据==" );
        System.out.println ( "pmsBrand:"+pmsBrand);
        return pmsBrandService.update ( pmsBrand );
    }

    @ApiOperation ( "全部品牌（翻页）" )
    @RequestMapping("findByPage")
    public PageResult<PmsBrand> findByPage(int pageNo,int pageSize){
        System.out.println ( "--pageno"+pageNo );
        System.out.println ( "--pagesize"+pageSize );
        return pmsBrandService.selectAllByPage ( pageNo,  pageSize );
    }

    @ApiOperation ( "根据品牌id获取品牌" )
    @RequestMapping("findById")
    public PmsBrand findById(int id){
        System.out.println ( "------id"+id);
        return pmsBrandService.seleteById ( id );
    }

    @ApiOperation ( "搜索品牌（翻页）" )
    @RequestMapping("findByKey")
    public PageResult<PmsBrand> findByKeywordPage(int pageNo,int pageSize,String keyword){
        System.out.println ( "--pageno"+pageNo );
        System.out.println ( "--pagesize"+pageSize );
        return pmsBrandService.selectAllByPage ( pageNo,pageSize,keyword );
    }

}
