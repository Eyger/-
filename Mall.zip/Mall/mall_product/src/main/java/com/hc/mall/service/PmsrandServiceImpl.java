package com.hc.mall.service;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.hc.mall.dto.PageResult;
import com.hc.mall.mapper.PmsBrandMapper;
import com.hc.mall.pojo.PmsBrand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class PmsrandServiceImpl implements IPmsBrandService{
    @Autowired
    PmsBrandMapper pmsBrandMapper;

    @Override
    public int deleteById(int id) {
        return pmsBrandMapper.deleteByPrimaryKey ( id );
    }

    @Override
    public int insert(PmsBrand pmsBrand) {
        return pmsBrandMapper.insert ( pmsBrand );
    }

    @Override
    public List<PmsBrand> selectAll() {
        return pmsBrandMapper.selectAll ();
    }

    @Override
    public PageResult<PmsBrand> selectAllByPage(int pageNo, int pageSize) {

        PageHelper.startPage ( pageNo,pageSize );
        Page<PmsBrand> page=(Page<PmsBrand>) pmsBrandMapper.selectAll ();
        PageResult<PmsBrand> pageResult=new PageResult<>( page.getTotal (),page.getResult());
        return  pageResult;
    }

    @Override
    public PmsBrand seleteById(int id) {
        return pmsBrandMapper.selectByPrimaryKey ( id );
    }

    @Override
    public int update(PmsBrand pmsBrand) {
        return pmsBrandMapper.updateByPrimaryKey ( pmsBrand );
    }

    @Override
    public PageResult<PmsBrand> selectAllByPage(int pageNo, int pageSize, String keyword) {
        PageHelper.startPage ( pageNo,pageSize,keyword );
        //Page<PmsBrand> page=(Page<PmsBrand>) pmsBrandMapper.selectAll ();
        //PageResult<PmsBrand> pageResult=new PageResult<>( page.getTotal (),page.getResult());
        //return  pageResult;
        return null;
    }
}
