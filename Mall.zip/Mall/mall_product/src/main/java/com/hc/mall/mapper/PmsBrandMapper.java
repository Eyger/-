package com.hc.mall.mapper;

import com.hc.mall.pojo.PmsBrand;
import tk.mybatis.mapper.common.Mapper;

public interface PmsBrandMapper extends Mapper<PmsBrand> {
    void insert(int id);
    void update(PmsBrand pmsBrand);
    void delete(int id);
    PmsBrand findById(int id);
    PmsBrand findByPage(int pageNo, int pageSize);

}
